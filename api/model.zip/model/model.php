<?php
  /**
   * Base Model Class
   */
  class Model  extends DBModel
  {
    function __construct()
    {
      parent::__construct();
    }
  }
?>